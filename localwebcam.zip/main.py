import torch
from model import load_model
from webcam import process_webcam_stream

def main():
    model_path = 'eye_tracking_model.pth'
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    model = load_model(model_path, device)
    process_webcam_stream(model, device)

if __name__ == "__main__":
    main()